import React from "react";

import {Text} from 'react-native';

export default function User (){
    return(
        <Text>
            Olá mundo lista!
        </Text>
    )
}