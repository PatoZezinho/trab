import { StyleSheet, Dimensions } from "react-native";
import {themas} from "../../global/themes"

export const style = StyleSheet.create({
  container:{
    flex:1,
    backgroundColor: 'white'
  },
  containerFoto:{
    alignItems:"center"
  },
  foto:{
    height: 250,
    width: 450
  }

    
})

