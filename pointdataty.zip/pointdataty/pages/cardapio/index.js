import {Image, View, TouchableOpacity} from 'react-native';
import {style} from './styles';
import restaurante from '../../assets/pointDaTaty.png'

export default function Cardapio(){
  return(
    <View style={style.container}>
    <View style={style.containerFoto}>
      <Image source={restaurante} style={style.foto} resizeMode='contain'></Image>
    </View>
    <TouchableOpacity>
    <Image>
    
    </Image>
    </TouchableOpacity>
    </View>
  )
}