import { StyleSheet } from "react-native";
import { themas } from "../../global/themes"; 
import { COLORS, FONT_SIZE } from "../../constants/themes";

export const style = StyleSheet.create({
    container: {
        flex: 1,
        padding:12,
        backgroundColor: COLORS.white, 
    },
    logo:{
      width: 200,
      height:30,
      
    },
    cart:{
      width:30,
      height:30
    },
    headerBar:{
      height: 45,
      flexDirection:"row",
      justifyContent:"space-between",
      
      
    },
    busca:{
      marginBottom:15,
      
    }
    
});
