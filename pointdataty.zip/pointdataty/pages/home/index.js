import { Image, View, Text, ScrollView, TouchableOpacity } from "react-native";
import { style } from "./style";
import icons from "../../constants/icons.js";
import { SafeAreaView } from "react-native-safe-area-context";
import TextBox from "../../components/textBox/index";
import { useState } from "react";
import Categorias from "../../components/Categoria/index";
import { categorias, banners, restaurantes } from "../../constants/dados.js";
import Banners from "../../components/banners/index";
import Restaurante from "../../components/restaurante/index";




function Home(props) {

  function OpenProduct() {
    props.navigation.navigate("Produtos")
  }

  const [busca, setBusca] = useState(""); // Inicialmente é definido como uma string vazia 

  return (
    <SafeAreaView style={style.container}>
      <View style={style.headerBar}>
        <Image source={icons.logo} style={style.logo} />
      </View>

      <View style={style.busca}>
        <TextBox 
          placeholder="O que vamos pedir hoje?"
          onChangeText={(texto) => setBusca(texto)} // Atualiza o estado com o texto digitado
          value={busca} 
        />
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>

        {/* Renderizando categorias */}
        <Categorias dados={categorias} />

        {/* Renderizando banners */}
        <Banners dados={banners} />

        {/* Renderizando a lista de restaurantes */}
        {restaurantes.map((restaurante, index) => {
          return (
            <TouchableOpacity key={index} onPress={OpenProduct}>
              <View>
                <Restaurante 
                  logotipo={restaurante.logotipo}
                  nome={restaurante.nome}
                  endereco={restaurante.endereco}
                  onPress={OpenProduct}
                  icone={icons.favoritofull} 
                />
              </View>
            </TouchableOpacity>
          );
        })}

      </ScrollView>

    </SafeAreaView>
  );
}

export default Home;
