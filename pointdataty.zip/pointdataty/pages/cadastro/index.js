import { View, Text, TouchableOpacity, ScrollView, Alert } from "react-native";
import { style } from "./styles"; 
import Header from '../../components/Header/index';
import Button from '../../components/Button2/index';
import TextBox from '../../components/textBox/index';
import { useState } from "react";
import AsyncStorage from '@react-native-async-storage/async-storage'; // Importando AsyncStorage corretamente

function Cadastro(props) {
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha1, setSenha1] = useState("");
  const [senha2, setSenha2] = useState("");

  const handleCadastro = async () => {
    if (senha1 !== senha2) {
      return Alert.alert('Erro', 'As senhas não coincidem');
    }

    try {
      console.log('Dados do usuário:', { nome, email, senha1 }); // Logando os dados do usuário

      // Verificando se já existe um usuário cadastrado com o mesmo email
      const existingEmail = await AsyncStorage.getItem('userEmail');
      if (existingEmail) {
        return Alert.alert('Erro', 'Este e-mail já está cadastrado');
      }

      // Armazenar as credenciais no AsyncStorage
      await AsyncStorage.setItem('userEmail', email);
      await AsyncStorage.setItem('userPassword', senha1); // Armazenando a senha

      console.log('Usuário cadastrado com sucesso'); // Confirmação de sucesso
      Alert.alert('Cadastro', 'Cadastro realizado com sucesso!');
      props.navigation.navigate("Login"); // Navegar para a tela de login após o cadastro
    } catch (error) {
      console.log('Erro ao cadastrar:', error);
      Alert.alert('Erro', 'Não foi possível cadastrar o usuário');
    }
  };

  return (
    <View style={style.container}>
      <ScrollView style={style.scrollView}>
        <Header texto="Criar sua conta." />

        <View style={style.formGroup}>
          <View style={style.form}>
            <TextBox label="Nome Completo" onChangeText={setNome} value={nome} />
          </View>

          <View style={style.form}>
            <TextBox label="E-mail" onChangeText={setEmail} value={email} />
          </View>

          <View style={style.form}>
            <TextBox label="Escolha uma senha" isPassword={true} onChangeText={setSenha1} value={senha1} />
          </View>

          <View style={style.form}>
            <TextBox label="Confirme a senha" isPassword={true} onChangeText={setSenha2} value={senha2} />
          </View>

          <View style={style.form}>
            <Button texto="Cadastre-se" onPress={handleCadastro} />
          </View>

          <TouchableOpacity onPress={() => props.navigation.navigate("Login")}>
            <Text style={style.footerText}>
              Já tem uma conta? Clique aqui!
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

export default Cadastro;
