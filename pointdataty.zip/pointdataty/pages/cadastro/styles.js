import { StyleSheet } from "react-native";
import { themas } from "../../global/themes"; 
import { COLORS, FONT_SIZE } from "../../constants/themes";

export const style = StyleSheet.create({
    container: {
        
        flex: 1,
        paddingLeft: 40,
        paddingRight: 40,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: COLORS.white, 
        
    },
    form: {
        width: "100%",
        marginBottom: 20,
    },
    scrollView: {
        width: "100%",
    },
    formGroup: {
        width: "100%",
        marginTop: 100,
        marginBottom: 40,
    },
    footer: {
        // width: "100%",
        // backgroundColor: 'white',
        // position: "absolute",
        // bottom: 0,
        // padding: 20,
        // height: 70,
       
        width: "100%",
        marginBottom: 1000,
       
    },
    footerText: {
        textAlign: "center",
        color: themas.colors.gray,
        fontSize: FONT_SIZE.md,
    },
});
