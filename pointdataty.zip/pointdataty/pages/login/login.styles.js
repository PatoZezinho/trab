import { Dimensions, StyleSheet } from "react-native";
import { themas } from "../../global/themes";
import { COLORS, FONT_SIZE } from "../../constants/themes"

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: COLORS.white
    }, 
    boxTop: {
        marginTop: 200,
        height: Dimensions.get('window').height / 3,
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
    },
    boxMid: {
        marginTop: 50,
        height: Dimensions.get('window').height / 4,
        width: '100%',
        paddingHorizontal: 37,
    },
    boxBotton: {
        height: Dimensions.get('window').height / 3,
        width: '100%',
        alignItems: 'center',
    },
    Logo2: {
        width: 300,
        height: 250,
    },
    Text: {
        fontWeight: 'bold',
        marginTop: 15,
        fontSize: 18,
    },
    subText: {
        marginTop: 5,
        color: themas.colors.gray,
    },
    titleInput: {
        marginLeft: 5,
        color: themas.colors.gray,
        marginTop: 20,
    },
    textBotton: {
        alignItems:'center',
        marginTop: 70,
        fontSize: 16,
        color: themas.colors.primary,
    },
    textBotton2: {
        fontSize: 16,
        color: themas.colors.option1,
    },
    footer: {
        width: "100%",
        backgroundColor: 'white',
        position: "absolute",
        bottom: 0,
        padding: 20,
        height: 70
    },
    footerText: {
        textAlign: "center",
        color:themas.colors.gray,
        fontSize: FONT_SIZE.md
    }
});
