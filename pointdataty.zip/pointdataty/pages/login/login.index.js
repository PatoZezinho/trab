import { Text, View, Image, TouchableOpacity, Alert, Pressable, Keyboard, Vibration } from 'react-native';
import * as React from 'react';
import { useState } from "react";
import Input from '../../components/input/input.index';
import { styles } from './login.styles'; 
import Logo2 from '../../assets/esta.png';
import { MaterialIcons, Octicons } from '@expo/vector-icons';
import Button from '../../components/Button/index'; 
import AsyncStorage from '@react-native-async-storage/async-storage'; // Importando AsyncStorage corretamente

export default function Login(props) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [loading, setLoading] = useState(false);
  const [showSenha, setShowSenha] = useState(true);

  const getLogin = async () => {
    try {
      setLoading(true);
      if (!email || !senha) {
        Vibration.vibrate();
        return Alert.alert('Atenção', 'Informe os campos obrigatórios');
      }

      // Recuperar os dados salvos no AsyncStorage
      const storedEmail = await AsyncStorage.getItem('userEmail');
      const storedPassword = await AsyncStorage.getItem('userPassword');

      console.log('Credenciais recuperadas:', { storedEmail, storedPassword }); // Verificando os dados salvos no AsyncStorage

      // Verificar se as credenciais coincidem
      if (storedEmail === email && storedPassword === senha) {
        Alert.alert('Login', 'Login efetuado com sucesso!');
        props.navigation.navigate("BottonRoutes"); // Navegar para a tela principal
      } else {
        Alert.alert('Erro', 'Credenciais incorretas');
      }
    } catch (error) {
      console.log('Erro no login:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Pressable onPress={Keyboard.dismiss} style={styles.container}>
      <View style={styles.boxTop}>
        <Image source={Logo2} style={styles.Logo2} resizeMethod="contain" />
        <Text style={styles.Text}>Bem Vindo de Volta!</Text>
        <Text style={styles.subText}>Point da Taty</Text>
      </View>
      <View style={styles.boxMid}>
      <Input
  value={email}
  onChangeText={setEmail}
  title="ENDEREÇO DE E-MAIL"
  IconLeft={MaterialIcons}
  IconLeftName='email'
  testID="email-input" // Adicione testID
/>
<Input
  value={senha}
  onChangeText={setSenha}
  title="SENHA"
  IconRight={Octicons}
  IconRightName='eye-closed'
  secureTextEntry={showSenha}
  testID="password-input" // Adicione testID
/>
      </View>
      <View style={styles.boxBotton}>
        <Button 
          text="Entrar" 
          loading={loading} 
          onPress={getLogin} 
        />
      </View>

      <View style={styles.footer}>
        <TouchableOpacity onPress={() => props.navigation.navigate("Cadastro")}>
          <Text style={styles.footerText}>
            Não tem uma conta? Crie agora!
          </Text>
        </TouchableOpacity>
      </View>
    </Pressable>
  );
}
