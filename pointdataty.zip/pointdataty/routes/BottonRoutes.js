import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import {Image} from 'react-native';
import Favoritos from '../pages/favoritos/index';
import Pedidos from "../pages/pedidos/index";
import Home from "../pages/home/index";
import icons from "../constants/icons"

const Tab = createBottomTabNavigator();
export default function BottomRoutes(){
    return(
    
        <Tab.Navigator 
        screenOptions={{
            tabBarShowLabel:false
        }}
       
        >
         <Tab.Screen
         name="Home"
         component={Home}
         options={{ 
           headerShown:false,
           tabBarIcon: ({focused}) =>{
              return <Image source={icons.abaHome} 
                            style={{width: 25, height:25, opacity:focused ? 1 : 0.3}}>
                            
                      </Image>
           }
           }}
         
         
        
         />
         <Tab.Screen
         name="Pedidos"
         component={Pedidos} 
         options={{ 
           
           tabBarIcon: ({focused}) =>{
              return <Image source={icons.abaPedido} 
                            style={{width: 25, height:25, opacity:focused ? 1 : 0.3}}>
                            
                      </Image>
           }
           }}
              
         />

         <Tab.Screen
         name="Favoritos"
         component={Favoritos}  
         options={{ 
           
           tabBarIcon: ({focused}) =>{
              return <Image source={icons.abaFavorito} 
                            style={{width: 25, height:25, opacity:focused ? 1 : 0.3}}>
                            
                      </Image>
           }
           }}     
         />



        </Tab.Navigator>

      
    );
}