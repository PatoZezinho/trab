import React, { forwardRef } from "react";
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import { themas } from "../../global/themes";
import {style} from "./styles"

const Input = forwardRef(({
     IconLeft,
     IconRight,
     IconLeftName,
     IconRightName,
     title,
     onIconLeftPress,
     onIconRightPress,
    ...rest
}, ref) => {
  

 return (
        <>
            <Text style={style.titleInput}>{title}</Text>
            <View style={style.boxInput}>
                 {IconLeft && IconLeftName && (
                    <TouchableOpacity onPress={onIconLeftPress}>
                        <IconLeft 
                            name={IconLeftName}
                            size={20}
                            color={themas.colors.gray}
                                    style={style.Icon1}//,{paddingLeft:calculateSizePaddingLeft(), width:calculateSizeWidth()
                        />
                    </TouchableOpacity>
                )} 

                <TextInput  
                    ref={ref}
                    style={style.Input}//,{width:calculateSizeWidth()}]}
                    {...rest}
                />

                {IconRight && IconRightName && (
                    <TouchableOpacity onPress={onIconRightPress}>
                        <IconRight
                            name={IconRightName}
                            size={20}
                            color={themas.colors.gray}
                            style={style.Icon}//,{paddingLeft:calculateSizePaddingLeft(), width:calculateSizeWidth()} ]}
                        />
                    </TouchableOpacity>
                )}
            </View>
        </>
    );
});

export default Input;


