import { Text, TextInput } from "react-native";
import { styles } from "./styles";


export default function TextBox(props) {
    return( <>{
      props.label &&<Text styel={styles.label}>{props.label}></Text>
    }
        <TextInput style={styles.input}
            placeholder={props.placeholder}
            secureTextEntry={props.isPassword}
            onChangeText={(texto) => props.onChangeText(texto)}
            value={props.value}
        />
    </>
    );
}

