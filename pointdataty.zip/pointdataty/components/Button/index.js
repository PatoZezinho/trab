import React from "react";
import { TouchableOpacity, ActivityIndicator, Text } from 'react-native';
import { style } from './styles';

export default function Button({ text, loading, ...rest }) {
  return (
    <TouchableOpacity 
      style={style.button} 
      {...rest} 
      activeOpacity={0.6}
    >
      {loading ? <ActivityIndicator /> : <Text style={style.textButton}>{text}</Text>}
    </TouchableOpacity>
  );
}
