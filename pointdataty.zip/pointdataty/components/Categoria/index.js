import {View, Text, Image, ScrollView} from "react-native";
import {styles} from "./styles"

export default function Categorias(props){
  return <View>
  <ScrollView horizontal = {true} showsHorizontalScrollIndicator={false}>
  {
    props.dados.map((Categorias, index)=>{
        return<View key={index} style={styles.categoria}>
            <Image style={styles.icone} source={Categorias.icone}></Image>
            <Text style={styles.descricao}>{Categorias.descricao}</Text>
         </View>
       
    })
    }
  </ScrollView>
  </View>
}