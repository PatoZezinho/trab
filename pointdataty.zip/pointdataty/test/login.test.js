import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import Login from '../pages/login/login.index'; 

describe('Login Screen', () => {
  it('deve renderizar as entradas de e-mail e senha', () => {
    const { getByTestId } = render(<Login />);

   
    expect(getByTestId('email-input')).toBeTruthy();
    expect(getByTestId('password-input')).toBeTruthy();
  });

  it('deve permitir a inserção de texto nos campos de e-mail e senha', async () => {
    const { getByTestId } = render(<Login />);

    const emailInput = getByTestId('email-input');
    const passwordInput = getByTestId('password-input');

    fireEvent.changeText(emailInput, 'test@example.com');
    fireEvent.changeText(passwordInput, 'password123');

    expect(emailInput.props.value).toBe('test@example.com');
    expect(passwordInput.props.value).toBe('password123');
  });

  it('deve exibir um alerta se o e-mail ou a senha estiverem vazios', async () => {
    const { getByText, getByTestId } = render(<Login />);

    const emailInput = getByTestId('email-input');
    const passwordInput = getByTestId('password-input');
    const loginButton = getByText('Entrar');

 
    fireEvent.changeText(emailInput, '');
    fireEvent.changeText(passwordInput, '');
    fireEvent.press(loginButton);

    
  
   
  });
});
