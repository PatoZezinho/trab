import { NavigationContainer } from '@react-navigation/native';
import Routes from './routes/index.routes';
import BottomRoutes from "./routes/BottonRoutes";

const isUserAuth = false;

export default function App() {
  return (
    <NavigationContainer>
      {isUserAuth ? <BottomRoutes /> : <Routes />}
    </NavigationContainer>
  );
}
