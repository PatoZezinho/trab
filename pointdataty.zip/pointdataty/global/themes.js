export const themas ={
    colors:{
        primary:"#FFC727",
        secondary:"#FF8973",
        option1:"#FF8973",
        option2:"#E1545C",
        lightGray:"#d7d8d7",
        bgScreen: '#f1f7fa',
        gray: 'gray'
 }
}