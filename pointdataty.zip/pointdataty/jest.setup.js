jest.mock('@expo/vector-icons', () => ({
    MaterialIcons: 'MaterialIcons',
    Octicons: 'Octicons',
  }));
  
  jest.mock('@react-native-async-storage/async-storage', () => ({
    getItem: jest.fn().mockResolvedValue(null),  
    setItem: jest.fn().mockResolvedValue(null),
    removeItem: jest.fn().mockResolvedValue(null),
  }));
  
  