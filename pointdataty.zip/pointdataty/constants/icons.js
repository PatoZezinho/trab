import back from "../assets/back.png";
import remove from "../assets/delete.png";
import logo from "../assets/this.png";
import cart from "../assets/cart.png";
import favoritofull from "../assets/favorito-full2.png";
import logo2 from "../assets/this.png";
import empty from "../assets/empty.png";

import abaHome from "../assets/aba-home.png";
import abaFavorito from "../assets/aba-favorito.png";
import abaPedido from "../assets/aba-pedidos.png";


export default { 
  back, 
  remove, 
  logo,
   cart,
    favoritofull,
    logo2, 
    empty,
    abaHome,
    abaFavorito,
    abaPedido
    };