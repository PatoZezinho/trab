export const categorias = [
    {
        id: 1,
        descricao: "Burguers",
        icone: require("../assets/cat-burguer.png")
    },
    {
        id: 2,
        descricao: "Pizza",
        icone: require("../assets/cat-pizza.png")
    },
    {
        id: 3,
        descricao: "Fritas",
        icone: require("../assets/cat-fritas.png")
    },
    {
        id: 4,
        descricao: "Sushi",
        icone: require("../assets/cat-sushi.png")
    },
    {
        id: 5,
        descricao: "Churrasco",
        icone: require("../assets/cat-churrasco.png")
    },
    {
        id: 6,
        descricao: "Sucos",
        icone: require("../assets/cat-suco.png")
    },
    {
        id: 7,
        descricao: "Doces",
        icone: require("../assets/cat-sobremesa.png")
    }
];

export const banners = [
    {
        id: 1,
        descricao: "Pizzas",
        icone: require("../assets/baner1.jpg")
    },
    {
        id: 2,
        descricao: "Comida Saudável",
        icone: require("../assets/baner2.jpg")
    }
];

export const restaurantes = [
    {
        id: 1,
        nome: "Pizza",
        endereco: "Massa extremamente leve e fofinha com sabores para tdos os gostos!.",
        logotipo: require("../assets/produto-pizza.png")
    },
    {
        id: 2,
        nome: "Fettuccine com camarão",
        endereco: "O mais deliciosomacarrão servido com molho vermelho e camarões",
        logotipo: require("../assets/Macarrao.jpg")
    },
    {
        id: 3,
        nome: "Feijoada da casa",
        endereco: "A Famosa feijoada da casa, acompanha arroz, couve, farofa e uma laranja fatiada",
        logotipo: require("../assets/produtofeijoada.jpg")
    },
    {
        id: 4,
        nome: "Pastel de Belém",
        endereco: "Deliciosa Sobremesa para toda família",
        logotipo: require("../assets/pasteldebelem.jpg")
    },
    {
        id: 5,
        nome: "Bife acebolado",
        endereco: "Nosso delicioso prato feito com alcatra, acompanha arroz, salada e fritas",
        logotipo: require("../assets/pf.jpg")
    },
    {
        id: 6,
        nome: "Bobó de Camarão",
        endereco: "Um pedacinho da culinária nordestina em nosso restaurante",
        logotipo: require("../assets/bobo.jpg")
    }
];

export const pedidos = [
    {
        id: 1,
         nome: "Pizza",
        status: "Entregue",
        dt_pedido: "10/05/2024",
        vl_total: 149,
        logotipo: require("../assets/produto-pizza.png")
    },
    {
        id: 2,
       nome: "Fettuccine com camarão",
        status: "Entregue",
        dt_pedido: "10/05/2024",
        vl_total: 52,
        logotipo: require("../assets/Macarrao.jpg")
    },
    {
        id: 3,
        nome: "Feijoada da casa",
        status: "Entregue",
        dt_pedido: "10/05/2024",
        vl_total: 71,
        logotipo: require("../assets/produtofeijoada.jpg")
    },
    {
        id: 4,
        nome: "Pastel de Belém",
        status: "Entregue",
        dt_pedido: "10/05/2024",
        vl_total: 29.90,
        logotipo: require("../assets/pasteldebelem.jpg")
    },
    {
        id: 5,
        nome: "Bife acebolado",
        status: "Entregue",
        dt_pedido: "10/05/2024",
        vl_total: 149,
        logotipo: require("../assets/pf.jpg")
    },
    {
        id: 6,
        nome: "Bobó de Camarão",
        status: "Entregue",
        dt_pedido: "10/05/2024",
        vl_total: 48,
        logotipo: require("../assets/bobo.jpg")
    }
    
     
];