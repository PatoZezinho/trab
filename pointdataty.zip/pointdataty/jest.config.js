module.exports = {
  preset: 'react-native',
  transformIgnorePatterns: [
    "node_modules/(?!(react-native|@react-native|@expo|expo|my-project|other-dependency)/)",
  ],
  transform: {
    "^.+\\.[t|j]sx?$": "babel-jest",
  },
  setupFiles: [
    './jest.setup.js', 
  ],
  moduleNameMapper: {
    '@react-native-async-storage/async-storage': require.resolve('@react-native-async-storage/async-storage'),
  },
};
