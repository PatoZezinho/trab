const categories = [
  {
    id: 2,
    name: "Refeição",
    },
  {
    id: 1,
    name: "Bebidas",
  },
  
  
  { id: 3, 
  name: "Tira gosto" 
  },
  {
    id: 4,
    name: "Refrigerante",
  },
  
];

export default categories;