export default {
  primary: "#D17842",
  secondary: "#52555A",
  dark: "#0C0F14",
  "dark-light": "#2E333E",
  light: "#4D4F52",
  white: "#fff",
  "white-smoke": "#b5b5b5",
  cinza: "#888888",
};