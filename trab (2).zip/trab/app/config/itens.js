export default [
{
    id: 1,
    name:"contra-file",
    image: require("../../assets/itens/contra-file.jpg"),
    price: "R$ 15,00",
    description:
      "",
    categoryId: 2,
   
  },
  {
    id: 2,
    name: "Carne assada",
    image: require("../../assets/itens/CarbeAssada.webp.jpg"),
    price: "R$ 15,00",
    description:
      "",
    categoryId: 2,
 
  },
  
  {
    id: 3,
    name: "Peixe",
    image: require("../../assets/itens/Peixe.jpg"),
    price: "R$ 15,00",
    description:
      ".",
  categoryId: 2
  },
  {
    id: 4,
    name: "Frango assado",
    image: require("../../assets/itens/Frangoassado.jpg"),
    price: "R$ 15,00",
    description:
      "",
   categoryId: 2
   
  },
{
    id: 5,
    name: "Feijoada",
    image: require("../../assets/itens/feijoada.jpg"),
    price: "R$ 15,00",
    description:
      "",
   categoryId: 2
   
  },
  {
    id: 6,
    name: "Coca-Cola 350ml Lata",
    image: require("../../assets/itens/cocacolalata.webp"),
    price: "R$ 6,00",
    description:
      "",
    categoryId: 4,
 
  },
  {
    id: 7,
    name: "Guarana 350ml Lata",
    image: require("../../assets/itens/Guaranalata.webp"),
    price: "R$ 5,00",
    description:
      "",
    categoryId: 4,
 
  },
  {
    id: 8,
    name: "Sukita 350ml Lata",
    image: require("../../assets/itens/Refrigerante-Sukita-Laranja-Lata-350ML-1.webp"),
    price: "R$ 5,00",
    description:
      "",
    categoryId: 4,
 
  },
  {
    id: 9,
    name: "Guaravita",
    image: require("../../assets/itens/guaravita"),
    price: "R$ 2,00",
    description:
      "",
    categoryId: 4,
 
  },
  {
    id: 10,
    name: "Heineken 350ml",
    image: require("../../assets/itens/Heneken.jpg"),
    price: "R$ 6,00",
    description:
      "",
    categoryId: 1,
 
  },
  {
    id: 11,
    name: "Brahma 350ml",
    image: require("../../assets/itens/brahma-lata-350ml.webp"),
    price: "R$ 6,00",
    description:
      "",
    categoryId: 1,
 
  },
  {
    id: 12,
    name: "Antarctica 350ml",
    image: require("../../assets/itens/antarctcaa.webp"),
    price: "R$ 8,00",
    description:
      "",
    categoryId: 1,
 
  },
  {
    id: 13,
    name: "Império 350ml",
    image: require("../../assets/itens/mpero.webp"),
    price: "R$ 5,00",
    description:
      "",
    categoryId: 1,
 
  },
];