import { SafeAreaView, ScrollView, StyleSheet, Image, View, TouchableOpacity, Text, Dimensions } from "react-native";  
import React, { useState } from "react";
import SPACING from "../config/SPACING";
import { BlurView } from "expo-blur";
import { Ionicons } from "@expo/vector-icons";
import colors from "../config/colors"; 
import SearchField from "../components/SearchField";
import Categories from "../components/Categories";
import itens from "../config/itens"; 

const avatar = require("../../assets/perfil.png");

const { width } = Dimensions.get("window");

const HomeScreen = () => {
    // Coloquei o estado dentro do componente
    const [activeCategoryId, setActiveCategoryId] = useState(null);

    return (
        <SafeAreaView>
            <ScrollView style={{
              padding: SPACING,
            }}>
                <View style={{
                    flexDirection: "row",  
                    justifyContent: "space-between",  
                }}>
                    <TouchableOpacity style={{
                        borderRadius: SPACING,
                        overflow: "hidden",
                        width: SPACING * 4,
                        height: SPACING * 4,
                    }}>
                        <BlurView intensity={50} style={{
                            height: "100%",
                            justifyContent: "center",
                            alignItems: "center",
                        }}>
                            <Ionicons 
                                name="menu" 
                                size={SPACING * 2.5} 
                                color={colors.secondary} 
                            />
                        </BlurView>
                    </TouchableOpacity>

                    <View style={{
                      width: SPACING * 4,
                      height: SPACING * 4,
                      overflow: "hidden",
                      borderRadius: SPACING,
                    }}>
                      <BlurView style={{
                        height: "100%",
                        padding: SPACING / 2,
                      }}>
                        <Image 
                          style={{
                            height: "100%", 
                            width: "100%",
                            borderRadius: SPACING,
                          }} 
                          source={avatar} 
                        />
                      </BlurView>
                    </View>
                </View>

                <View style={{ width: "80%", marginVertical: SPACING * 3 }}>
                  <Text style={{
                    color: colors.dark, 
                    fontSize: SPACING * 3.5,
                    fontWeight: "600",
                  }}>
                    Melhor comida da região
                  </Text>
                </View>

                <SearchField />
                {/* Correção no onChange para setActiveCategoryId */}
                <Categories onChange={(id) => setActiveCategoryId(id)} />

               <View style={{
                 flexDirection: "row",
                 flexWrap: "wrap",
                 justifyContent: "space-between",
               }}>
                {/* Correção no filtro */}
                {itens.filter((item) => {
                  if (activeCategoryId === null) return true;  // Mostra todos os itens se activeCategoryId for null
                  return item.categoryId === activeCategoryId;   // Mostra apenas itens da categoria ativa
                }).map((item, index) => (
                  <View key={item.id} style={{ 
                  width: width / 2.2, 
                  marginBottom: 10,
                  borderRadius: 20,
                  overflow: "hidden"
                   }}>
                   
                      <BlurView 
                        tint="dark"
                        intensity={10} 
                        style={{
                          borderRadius: 5,
                          overflow: "hidden",
                          padding: 10,
                        }}
                      >
                        
                        <View style={{
                          ...StyleSheet.absoluteFillObject,
                          backgroundColor: 'rgba(88, 88, 88, 0.3)',  
                        }} />

                        <TouchableOpacity style={{
                          height: 150,
                          width: "100%",
                        }}>
                          <Image 
                            source={item.image} 
                            style={{ 
                              width: "100%", 
                              height: "100%", 
                              borderRadius: 18 ,
                            }} 
                          />
                        </TouchableOpacity>

                        <Text style={{ 
                              color: colors.white, 
                              fontWeight: "600",
                              fontSize: 20,
                              marginTop: 7,
                              marginBottom: 0,
                            }}>
                          {item.name}
                        </Text>
                        
                        <View>
                          <Text style={{
                            color: colors.white,
                            fontSize: 15,
                          }}>
                            {item.price}
                          </Text>
                        </View>
                    </BlurView>
                    
                  </View>
                ))}
              </View>
            </ScrollView>
        </SafeAreaView>
    );
};

export default HomeScreen;

const styles = StyleSheet.create({});
