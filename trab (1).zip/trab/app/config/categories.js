const categories = [
  {
    id: 1,
    name: "Bebidas",
  },
  {
    id: 2,
    name: "Refeição",
  },
  { id: 3, name: "Tira gosto" },
  {
    id: 4,
    name: "Refrigerante",
  },
  
];

export default categories;