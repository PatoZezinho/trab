export default [
{
    id: 1,
    name:"contra-file",
    image: require("../../assets/itens/contra-file.jpg"),
    price: "R$ 15,00",
    description:
      "",
    categoryId: 2,
   
  },
  {
    id: 2,
    name: "Carne assada",
    image: require("../../assets/itens/CarbeAssada.webp.jpg"),
    price: "R$ 15,00",
    description:
      "",
    categoryId: 2,
 
  },
  {
    id: 3,
    name: "Peixe",
    image: require("../../assets/itens/Peixe.jpg"),
    price: "R$ 15,00",
    description:
      ".",
  categoryId: 2
  },
  {
    id: 4,
    name: "Frango assado",
    image: require("../../assets/itens/Frangoassado.jpg"),
    price: "R$ 15,00",
    description:
      "",
   categoryId: 2
   
  },
{
    id: 4,
    name: "Feijoada",
    image: require("../../assets/itens/feijoada.jpg"),
    price: "R$ 15,00",
    description:
      "",
   categoryId: 2
   
  },
];