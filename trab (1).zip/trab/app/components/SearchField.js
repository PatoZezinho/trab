import { TextInput, StyleSheet, Text, View } from "react-native";
import React from "react";
import { BlurView } from "expo-blur"; 
import colors from "../config/colors";

import { Ionicons } from "@expo/vector-icons";

const SearchField = () => {
  return (
    <View style={{
      borderRadius: 10,
      overflow: "hidden",
    }}>
      <BlurView 
      intensity={30} 
      style={{
        alignItems:"center",
        justifyContent:"center"
        
      }}>
        <TextInput 
          style={{
            width: "100%",
           
            color: colors.white,
            fontSize: 20,
            padding: 10,
            paddingLeft: 35,
          }} 
          placeholder="Pesquise uma comida..." 
          placeholderTextColor={colors.light} 
        />
        <Ionicons style={{
          position:"absolute",
          left: 10,
        }} name="search" 
        color={colors.light} 
        size={23}
        />
      </BlurView>
    </View>
  );
};

export default SearchField;

const styles = StyleSheet.create({});
